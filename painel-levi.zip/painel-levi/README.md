# Bot Tempest 🌪

Bot de Discord (discord.js v14) com comandos de economia (`saldo`, `daily`, `apostar`) e moderação (`ban`, `mutar`, `desmutar`, `expulsar`, `slowmode`, `ping`), em modo prefixo (`;comando`) e slash (`/comando`).

## Como as moedas ficam salvas

As moedas ("Tempestades") **não ficam na memória** — todo saldo é lido e escrito no arquivo `economy.json`, na mesma pasta do bot, através de `fs.readFileSync` / `fs.writeFileSync`. Isso quer dizer:

- Toda vez que alguém ganha ou perde moedas, o arquivo é atualizado na hora.
- Se o bot cair, reiniciar ou você fizer deploy de novo, ele lê o `economy.json` já existente e continua de onde parou.
- **Nunca apague o `economy.json`** (a menos que queira zerar tudo).

O mesmo vale para os outros estados:
- `cmd-states.json` → comandos ativados/desativados
- `bot-state.json` → prefixo configurado (lido por `getPrefix()`)

> ⚠️ Se você hospedar em serviços com **disco efêmero** (ex: alguns free tiers que resetam o filesystem a cada deploy/restart), o `economy.json` pode ser apagado junto. Nesses casos, ou fixe um volume persistente (Railway/Render Disks, Docker volume, VPS normal), ou migre para um banco de dados (posso te ajudar a trocar para SQLite/MongoDB se for o seu caso).

## Configuração

1. Instale as dependências:
   ```bash
   npm install
   ```

2. Renomeie `.env.example` para `.env` e cole seu token:
   ```env
   TOKEN=SEU_TOKEN_AQUI
   PAINEL_API=
   ```
   O token é pego em: https://discord.com/developers/applications → sua aplicação → **Bot** → **Reset Token**.

   ⚠️ Nunca compartilhe esse token nem suba o `.env` para o GitHub (o `.gitignore` já protege isso).

3. Rode o bot:
   ```bash
   npm start
   ```

## Estrutura de arquivos gerados automaticamente

| Arquivo | Conteúdo |
|---|---|
| `economy.json` | saldo e último `daily` de cada usuário |
| `cmd-states.json` | quais comandos estão ligados/desligados (usado pelo painel) |
| `bot-state.json` | prefixo atual do bot (usado pelo painel) |

Esses arquivos são criados sozinhos na primeira vez que forem necessários — não precisa criar na mão.
